% +DEMOS
%
% Files
%   bayesnetdemo - Creating, viewing and sampling a Bayesian network

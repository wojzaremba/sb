% +DEMOS
%
% Files
%   jtreedemo - Bayesian network inference using the junction-tree algorithm

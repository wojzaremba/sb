% +BIF
%
% Files
%   bifread - Read Bayesian network from BIF file.

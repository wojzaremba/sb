% +HUGIN
%
% Files
%   huginread - Read Bayesian network from HUGIN file.

% +GL
%
% Files
%   glglearner - Generalized-local-to-global learner.

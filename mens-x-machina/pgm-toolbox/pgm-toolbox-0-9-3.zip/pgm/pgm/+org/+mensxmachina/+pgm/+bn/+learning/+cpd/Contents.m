% +CPD
%
% Files
%   cpdlearner - Conditional-probability-distribution learner.

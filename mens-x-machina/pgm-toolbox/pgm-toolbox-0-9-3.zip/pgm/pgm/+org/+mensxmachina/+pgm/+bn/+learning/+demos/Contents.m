% +DEMOS
%
% Files
%   mmhcdemo - Applying the MMPC, MMPC-skeleton and MMHC algorithms

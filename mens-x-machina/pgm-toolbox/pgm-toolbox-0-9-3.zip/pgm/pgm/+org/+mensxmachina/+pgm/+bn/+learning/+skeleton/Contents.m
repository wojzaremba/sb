% +SKELETON
%
% Files
%   skeletonlearner - Skeleton learner.

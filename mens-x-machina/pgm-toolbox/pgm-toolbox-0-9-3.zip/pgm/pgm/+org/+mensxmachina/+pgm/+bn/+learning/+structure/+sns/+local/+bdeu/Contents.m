% +BDEU
%
% Files
%   bdeulocalscorer - BDeu local scorer.

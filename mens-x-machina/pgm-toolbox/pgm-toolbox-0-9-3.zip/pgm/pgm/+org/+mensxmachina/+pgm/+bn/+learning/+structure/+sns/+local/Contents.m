% +LOCALSCORERS
%
% Files
%   localscorer - Local scorer.

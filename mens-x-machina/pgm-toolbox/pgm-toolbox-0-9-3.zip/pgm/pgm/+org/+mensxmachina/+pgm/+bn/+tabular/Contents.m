% +TABULAR
%
% Files
%   sprinkler - Create the example sprinkler Bayesian network.

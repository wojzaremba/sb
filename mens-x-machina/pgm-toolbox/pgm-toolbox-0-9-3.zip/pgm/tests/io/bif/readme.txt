These tests require the following files to be on the path: 

- alarm.bif, downloadable from http://www.cs.huji.ac.il/~galel/Repository/
- Causal Explorer, downloadable from http://www.dsl-lab.org/causal_explorer/index.html. PCodes/assert.p must be removed in order for the tests to run.
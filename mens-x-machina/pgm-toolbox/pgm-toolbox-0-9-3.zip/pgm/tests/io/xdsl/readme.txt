These tests require the following files to be on the path: 

- alarm.bif, Diabetes.net, Link.net, Mildew.net, Water.net downloadable from http://www.cs.huji.ac.il/~galel/Repository/
- alarm.xdsl, diabetes.xdsl, hailfinder.xdsl, link.xdsl, Mildew.xdsl, and Water.xdsl, downloadable from http://genie.sis.pitt.edu/networks.html
- Causal Explorer, downloadable from http://www.dsl-lab.org/causal_explorer/index.html. PCodes/assert.p must be removed in order for the tests to run.
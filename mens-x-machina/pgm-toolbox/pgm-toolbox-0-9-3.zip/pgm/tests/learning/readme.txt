These tests require the following files to be on the path: 

- alarm.bif and alarm.net downloadable from 
http://www.cs.huji.ac.il/~galel/Repository/
- alarm.xdsl downloadable from http://genie.sis.pitt.edu/networks.html
- alarm.xml03 in Examples/Alarm directory of JavaBayes, downloadable from 
http://www.cs.cmu.edu/~javabayes/Home/node3.html
- Causal Explorer, downloadable from 
http://www.dsl-lab.org/causal_explorer/index.html. PCodes/assert.p must be 
removed in order for the tests to run.

...and the following files to be on the JAVA path: 

- PowerBayes, downloadable from http://kdl.cs.umass.edu/powerbayes/.
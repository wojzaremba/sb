 Everything is in the user/developer manual.

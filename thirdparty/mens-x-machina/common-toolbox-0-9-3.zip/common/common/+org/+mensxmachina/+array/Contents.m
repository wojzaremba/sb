% +ARRAY
%
% Files
%   isorder   - Determine whether input is an order vector.
%   issize    - Determine whether input is a size vector.
%   makeorder - Make order vector.
%   makesize  - Make size vector.

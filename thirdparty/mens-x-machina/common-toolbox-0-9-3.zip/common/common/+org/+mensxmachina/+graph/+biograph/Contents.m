% +BIOGRAPH
%
% Files
%   closeallbiographviewers - Close all biograph viewers.

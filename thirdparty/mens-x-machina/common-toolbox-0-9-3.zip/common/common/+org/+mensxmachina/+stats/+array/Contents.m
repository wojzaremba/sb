% +DATA
%
% Files
%   datasetvarnvalues - Number of possible values of each dataset-array variable.
%   datasetvarvalues  - Possible values of each dataset-array variable.

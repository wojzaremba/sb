% +LG
%
% Files
%   lingausscpd - Linear Gaussian conditional probability distribution.

% +TABULAR
%
% Files
%   maketabcpdvalues - Create tabular conditional probability distribution values.
%   tabcpd           - Tabular conditional probability distribution.
%   tabpotential     - Tabular potential.

% +CPD
%
% Files
%   cpd        - Conditional probability distribution.
%   cpdvartype - Type of conditional-probability-distribution variable.
%   potential  - Potential.

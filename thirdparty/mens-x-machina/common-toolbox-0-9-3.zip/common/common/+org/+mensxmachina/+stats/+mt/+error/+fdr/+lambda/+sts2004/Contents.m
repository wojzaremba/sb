% +STS2004
%
% Files
%   sts2004fdrestimator - Storey, Taylor and Siegmund (2004) FDR estimator.

% +LAMBDA
%
% Files
%   lambdafdrestimator - FDR estimator with parameter lambda.

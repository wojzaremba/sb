% +QUANTITIES
%
% Files
%   ndiscoveries - Number of discoveries.
%   ntype1errors - Number of type I errors.
%   ntype2errors - Number of type II errors.

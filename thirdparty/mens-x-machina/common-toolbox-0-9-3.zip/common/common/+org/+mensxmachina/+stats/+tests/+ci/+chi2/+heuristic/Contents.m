% +HEURISTIC
%
% Files

%   heuristicapplier        - Heuristic-power-rule applier.
%   heuristicminnobsbounder - Heuristic-power-rule minimal-sample-size bounder.

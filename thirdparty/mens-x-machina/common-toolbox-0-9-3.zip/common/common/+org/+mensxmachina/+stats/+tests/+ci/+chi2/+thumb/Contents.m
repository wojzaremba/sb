% +THUMB
%
% Files
%   thumbapplier - Rule-of-thumb applier.

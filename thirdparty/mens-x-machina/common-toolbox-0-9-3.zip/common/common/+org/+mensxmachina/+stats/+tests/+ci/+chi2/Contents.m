% +CHI2
%
% Files
%   chi2citpvalueestimator          - Chi-square-test-of-conditional-independence-p-value estimator.
%   gtestpvalueestimator            - G-test-p-value estimator.
%   pearsonschi2testpvalueestimator - Pearson's-Chi-square-test-of-conditional-independence p-value estimator.

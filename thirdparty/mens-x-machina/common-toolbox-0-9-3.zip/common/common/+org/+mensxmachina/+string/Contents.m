% +STRING
%
% Files
%   strfirstupper - Convert the first letter of a string to upper case.
%   strjoin       - Join strings.

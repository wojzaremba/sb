These tests require the following files to be on the JAVA path: 

- PowerBayes, downloadable from 
http://kdl.cs.umass.edu/powerbayes/.
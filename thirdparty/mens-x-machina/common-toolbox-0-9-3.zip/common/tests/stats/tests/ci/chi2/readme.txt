These tests require Causal Explorer to be on the path.

Causal Explorer can be downloaded from http://www.dsl-lab.org/causal_explorer/index.html.

PCodes/assert.p must be removed in order for the tests to run.

Due to their stochastic nature, the tests may have to run several times before they succeed.